<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['clg_Students'] = 'Students';
$app_list_strings['moduleList']['clg_Teachers'] = 'Teachers';
$app_list_strings['moduleList']['clg_Disciplines'] = 'Disciplines';
$app_list_strings['moduleListSingular']['clg_Students'] = 'Student';
$app_list_strings['moduleListSingular']['clg_Teachers'] = 'Teacher';
$app_list_strings['moduleListSingular']['clg_Disciplines'] = 'Discipline';
$app_list_strings['account_type_dom']['Assistant Professor'] = 'Assistant Professor';
$app_list_strings['account_type_dom']['Associate Professor'] = 'Associate Professor';
$app_list_strings['account_type_dom']['Professor'] = 'Professor';
$app_list_strings['account_type_dom']['Visiting Faculty'] = 'Visiting Faculty';
$app_list_strings['account_type_dom'][''] = '';
